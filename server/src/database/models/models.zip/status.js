import { DataTypes } from "sequelize";
import { sequelize } from "../config/database.js";

export const Status = sequelize.define('Status', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    code: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
}, {
    tableName: 'status',
    timestamps: true,
    paranoid: true,
});

Status.afterSync(async () => {
    const initialState = [
        { code: "active", name: 'Activo' },
        { code: "inactive", name: 'Inactivo' },
        { code: "pending", name: 'Pendiente' },
        { code: "rejected", name: 'Rechazado' },
        { code: "banned", name: 'Baneado' },
        { code: "shadowban", name: 'Shadowban' },
        { code: "deleted", name: 'Eliminado' },
        { code: "suspended", name: 'Suspendido' },
        { code: "unverified", name: 'No verificado' },
        { code: "verified", name: 'Verificado' },
        { code: "invited", name: 'Invitado' },
        { code: "homo", name: 'Le dio Puto' },
    ];

    for (const stateData of initialState) {
        try {
            await Status.findOrCreate({
                where: { code: stateData.code },
                defaults: stateData
            });
        } catch (error) {
            console.error("Error seeding category:", error);
        }
    }
    console.log("Categories seeded successfully");
});