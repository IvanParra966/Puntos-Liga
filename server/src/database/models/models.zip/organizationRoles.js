import { DataTypes } from "sequelize";
import { sequelize } from "../config/database.js";

export const OrganizationRoles = sequelize.define('OrganizationRoles', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    code: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
}, {
    tableName: 'organization_roles',
    timestamps: true,
    paranoid: true,
});

OrganizationRoles.afterSync(async () => {
    const initialState = [
        { code: "owner", name: 'Dueño' },
        { code: "organizer", name: 'Organizador' },
    ];

    for (const stateData of initialState) {
        try {
            await OrganizationRoles.findOrCreate({
                where: { code: stateData.code },
                defaults: stateData
            });
        } catch (error) {
            console.error("Error seeding category:", error);
        }
    }
    console.log("Categories seeded successfully");
});