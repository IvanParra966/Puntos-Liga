import { DataTypes } from "sequelize";
import { sequelize } from "../config/database.js";

export const OrganizationMembers = sequelize.define('OrganizationMembers', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    organizationId: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    organizationRoleId: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    status: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 1,
    },
}, {
    tableName: 'organization_members',
    timestamps: true,
    paranoid: true,
});