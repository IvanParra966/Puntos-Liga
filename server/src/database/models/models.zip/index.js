import { User } from './users.js';
import { Roles } from './roles.js';
import { Status } from './status.js';
import { OrganizationRoles } from './organizationRoles.js';
import { OrganizationMembers } from './organizationMembers.js';

/*Borrar luego */
import { Player } from './player.js';
import { Season } from './season.js';
import { Tournament } from './tournament.js';
import { TournamentResult } from './tournamentResult.js';
import { TournamentMatch } from './tournamentMatch.js';
import { PointRule } from './pointRule.js';
import { SyncState } from './syncState.js';
import { Keyword } from './keyword.js';


/*  roles - users */
User.belongsTo(Roles, { foreignKey: 'roleId', as: 'roles', });
Roles.hasMany(User, { foreignKey: 'roleId', as: 'users', });

/* status - users */
User.belongsTo(Status, { foreignKey: 'status', as: 'status', });
Status.hasMany(User, { foreignKey: 'status', as: 'users', });

/* status - organizationMembers */
OrganizationMembers.belongsTo(Status, { foreignKey: 'status', as: 'status', });
Status.hasMany(OrganizationMembers, { foreignKey: 'status', as: 'organizationMembers', });

/* organizationRoles - organizationMembers */
OrganizationMembers.belongsTo(OrganizationRoles, { foreignKey: 'organizationRoleId', as: 'organizationRoles', });
OrganizationRoles.hasMany(OrganizationMembers, { foreignKey: 'organizationRoleId', as: 'organizationMembers', });

/* users - organizationMembers */
OrganizationMembers.belongsTo(User, { foreignKey: 'userId', as: 'users', });
User.hasMany(OrganizationMembers, { foreignKey: 'userId', as: 'organizationMembers', });

export {
  User,
  Roles,
  /*Borrar luego */
  Player,
  Season,
  Tournament,
  TournamentResult,
  TournamentMatch,
  PointRule,
  SyncState,
  Keyword
};
