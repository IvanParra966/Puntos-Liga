import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

export const Roles = sequelize.define('Roles', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
    },
    description: {
        type: DataTypes.STRING,
        allowNull: true,
    },
},
    {
        tableName: 'roles',
        timestamps: true,
        paranoid: true,
    }
);

Roles.afterSync(async () => {
    const initialState = [
        { name: 'admin', description: 'Administrador del sistema' },
        { name: 'player', description: 'Jugador del sistema' },
    ];

    for (const stateData of initialState) {
        try {
            await Roles.findOrCreate({
                where: { name: stateData.name },
                defaults: stateData
            });
        } catch (error) {
            console.error("Error seeding category:", error);
        }
    }
    console.log("Categories seeded successfully");
});